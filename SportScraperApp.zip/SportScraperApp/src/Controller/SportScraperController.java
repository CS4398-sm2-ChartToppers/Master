package Controller;
import java.util.ArrayList;
import javax.swing.*;

import Model.Model;
import Model.RetrieveRS;
import Model.StoreDB;
import View.SportScraperView;
import View.View;

public class SportScraperController implements Controller{
	private View view;
	private Model model;
	
	public SportScraperController() {
		setModel(new RetrieveRS());
		setView(new SportScraperView(this, (RetrieveRS)getModel()));
	}
	
	public View getView() { return this.view; }
	public Model getModel() { return this.model; }
	public void setView(View view) { this.view = view; }
	public void setModel(Model model) { this.model = model; }
	
	public void getSelection(String sport) {
		switch(sport) {
			case "NHL Stats" : 
				view.setTableModel(StoreDB.QueryToTableModel("SELECT * FROM NHL ORDER BY \"W Wins\" DESC;"));
				break;
			case "MLB Stats" : 
				view.setTableModel(StoreDB.QueryToTableModel("SELECT * FROM MLB ORDER BY \"W Wins\" DESC;"));
				break;
			case "NFL Stats" : 
				view.setTableModel(StoreDB.QueryToTableModel("SELECT * FROM NFL ORDER BY \"W Wins\" DESC;"));
				break;
			default :
				break;
		}
	}
	
	public void printStats(ArrayList<ArrayList<Double>> statList) {
		SportScraperView tempView = (SportScraperView) getView();
		SportScraperView tempPane = (SportScraperView) tempView.getContentPane();
		JTable tempTable = new JTable();
		/*
		 * From here one would extract the values from our data structure
		 * and add them to the JTable, and then adding that onto the container.
		 * 
		 * tempPane is assigned to the content pane, which is how the JTable can be
		 * added.
		 */
	}

}
