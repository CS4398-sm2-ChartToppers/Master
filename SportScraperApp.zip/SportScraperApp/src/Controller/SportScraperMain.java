package Controller;

import java.io.IOException;

import parser.CbsSportsParser;
import parser.ScrapedData;

public class SportScraperMain {
	public static void main(String[] args) throws IOException {
		//lazy testing to show how the parser works
		ScrapedData data = CbsSportsParser.parse("https://www.cbssports.com/college-football/standings/");
		//System.out.println(data.getColumnHeaders());
		data.displayTeamStats();
		
		new SportScraperController();
	}
}
