package Controller;

import parser.ParserFactory;
import parser.StandingsParser;

import static parser.ParserEnum.MLB_PARSER;

public class SportScraperMain {
	public static void main(String[] args) {
		ParserFactory a = new ParserFactory();
		StandingsParser NFLParser = a.getParser(MLB_PARSER);
		new SportScraperController();
	}
}
