package Model;

public interface Model {
	void execute(String sport);
}
