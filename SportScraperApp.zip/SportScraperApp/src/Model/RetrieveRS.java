package Model;

public class RetrieveRS implements Model{
	public RetrieveRS() {
		
	}
	
	public void execute(String qCommand) {
		System.out.println(qCommand);
	}
}
