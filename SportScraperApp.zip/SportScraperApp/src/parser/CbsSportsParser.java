package parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class CbsSportsParser implements StandingsParser {

	Document htmlDocument;
	
	public CbsSportsParser (Document html) {
		this.htmlDocument = html;
	}
	
	public CbsSportsParser (String url) {
		final ExecutorService executor =  Executors.newFixedThreadPool(5);
		final List<Future<List<String>>> futures = new ArrayList<>();
		try {
			htmlDocument = Jsoup.connect(url).get();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}
	
	public static ScrapedData parse(String url) throws IOException {
		/* Will parse most of the sports with HTML Tables on CbsSports 
		 * urls: /nfl/standings/
		 * 		 /nba/standings/regular/division/
		 * 	     /mlb/standings/regular/
		 * 		 /nhl/standings/
		 * 		 /college-football/standings/
		 */
		List<String> colHeaders = new ArrayList<String>();
		List<List<String>> teamStats = new ArrayList<List<String>>();
		final long timeStart = System.currentTimeMillis();
		//Get HTML file from url
		Document htmlFile = Jsoup.connect(url).maxBodySize(0).get();
		//PARSE COLUMN HEADERS
		colHeaders = getHeaders(htmlFile, colHeaders);
		//PARSE TEAM + STATS
		teamStats = getTeamStats(htmlFile, teamStats);
		final long timeEnd = System.currentTimeMillis();
		System.out.println("TIME TO PARSE: " + (timeEnd - timeStart));
		
		return new ScrapedData(colHeaders,teamStats);
	}
	
	private static List<String> getHeaders(Document htmlFile, List<String> colHeaders) {
		for(Element headers : htmlFile.select("th")) 
		{
			if(headers.text().equals("")) {
				
			}
			else {
				if(headers.text().equals("W Wins")) 
				{
					do
					{
						colHeaders.add(headers.text());
						headers = headers.nextElementSibling();
						
					}while(headers != null);
					break;
				}
			}
		}
		return colHeaders;
	}
	
	private static List<List<String>> getTeamStats(Document htmlFile, List<List<String>> teamStats){
		boolean repeat = false;
		boolean breakOutter = false;
		String firstTeam = null;
		for(Element row : htmlFile.select("tr")){
			if(breakOutter == true) {
				break;
			}
			ArrayList<String> team = new ArrayList<String>();
			for(Element tds: row.select("td")) {
				
				if (repeat == true && firstTeam.equals(tds.text())) {
					breakOutter = true;
					break;
				}
				if (repeat == false){
					firstTeam = tds.text();
					repeat = true;
				}
				team.add(tds.text());
			}
			teamStats.add(team);
		}
		teamStats.removeIf(list -> list.isEmpty());
		
		return teamStats;
	}
	
	@Override
	public void run() {
	// TODO Auto-generated method stub
		
	}

}
