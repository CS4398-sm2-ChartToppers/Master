package parser;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class CbsSportsParser implements StandingsParser {

	Document htmlDocument;
	
	public CbsSportsParser (Document html) {
		this.htmlDocument = html;
	}
	
	public CbsSportsParser (String url) {
		try {
			htmlDocument = Jsoup.connect(url).get();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}
	
	public static ScrapedData parse(String url) throws IOException {
		/* Will parse most of the sports with HTML Tables on CbsSports 
		 * URLS: /nfl/standings/
		 * 		 /nba/standings/regular/division/
		 * 	     /mlb/standings/regular/
		 * 		 /nhl/standings/
		 * 		 /college-football/standings/
		 */
		final List<String> colHeaders, imgUrls;
		final List<List<String>> teamStats;
		
		//Get HTML file from URL
		Document htmlFile = Jsoup.connect(url).maxBodySize(0).get();
		//Parse
		colHeaders = getHeaders(htmlFile);
		teamStats = getTeamStats(htmlFile);
		imgUrls = getImageURLS(htmlFile);
				
		return new ScrapedData(colHeaders,teamStats, imgUrls);
	}
	
	private static List<String> getHeaders(Document htmlFile) {
		List<String> colHeaders = new ArrayList<String>();
		for(Element headers : htmlFile.select("th")) 
		{
			if(headers.text().equals("")) {
				
			}
			else {
				if(headers.text().equals("W Wins")) 
				{
					do
					{
						colHeaders.add(headers.text());
						headers = headers.nextElementSibling();
						
					}while(headers != null);
					break;
				}
			}
		}
		return colHeaders;
	}
	
	private static List<List<String>> getTeamStats(Document htmlFile){
		/*
		 * cbssports.com repeats the same information on their page multiple
		 * times using the same HTML tags and elements. 
		 * 
		 * In order to not pull duplicates, the function
		 * stores the first team name inside of firstTeam variable
		 * and sets repeat state to true.
		 * 
		 * Its not pretty, but it works.
		 * 
		 * Optimize if time allows
		 */
		List<List<String>> teamStats = new ArrayList<List<String>>();
		boolean repeat = false;
		boolean breakOutter = false;
		String firstTeam = null;
		for(Element row : htmlFile.select("tr")){
			if(breakOutter == true) {
				break;
			}
			ArrayList<String> team = new ArrayList<String>();
			for(Element tds: row.select("td")) {
				
				if (repeat == true && firstTeam.equals(tds.text())) {
					breakOutter = true;
					break;
				}
				if (repeat == false){
					firstTeam = tds.text();
					repeat = true;
				}
				team.add(tds.text());
			}
			teamStats.add(team);
		}
		teamStats.removeIf(list -> list.isEmpty());
		
		return teamStats;
	}
	
	private static List<String> getImageURLS(Document htmlFile) {
		/*
		 * cbssports.com repeats the same information on their page multiple
		 * times using the same HTML tags and elements. 
		 * 
		 * In order to not pull duplicates, the function
		 * stores the first URL string inside of firstUrl variable
		 * and sets repeat state to true.
		 * 
		 */
		List<String> imgUrls = new ArrayList<String>();
		boolean repeat = false;
		String firstUrl = null;
		for (Element img : htmlFile.select("img")) {
			if(repeat == true && urlEquals(firstUrl, img.attr("data-lazy")))
				break;
			if(img.attr("alt").equals("team logo")) {
				imgUrls.add(img.attr("data-lazy"));
				if(repeat = false) {
					firstUrl = img.attr("data-lazy");
					repeat = true;
				}
			}
			
		}
		
		return imgUrls;
	}
	
	private static boolean urlEquals(String firstUrl, String secondUrl) {
		int checkLastDigits = 7;
		if(firstUrl.length() == secondUrl.length()) {
			char v1[] = firstUrl.toCharArray();
			char v2[] = secondUrl.toCharArray();
			int i = 0;
			int j = 0;
			while(checkLastDigits != 0) {
				if(v1[i--] !=  v2[i--]) {
					return false;
				}
			}
			return true;
		}
		else {
			return false;
		}
		
	}
	
	@Override
	public void run() {
	// TODO Auto-generated method stub
		
	}

}
