package parser;

public class MLBParser implements StandingsParser 
{
	public MLBParser() {
		System.out.println("MLBParser created");
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
	
}
