package parser;

public class NBAParser implements StandingsParser
{
	public NBAParser () {
		System.out.println("NBAParser created!");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}