package parser;

public class NFLParser implements StandingsParser
{
	
	public NFLParser () {
		System.out.println("NFLParser created!");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
}
