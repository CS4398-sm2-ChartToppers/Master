package parser;

import java.util.ArrayList;
import java.util.List;

public class ScrapedData {
	List<List<String>> teamStats;
	List<String> columnHeaders;
	public ScrapedData(List headers, List<List<String>> values) {
		columnHeaders = headers;
		teamStats = values;
	}
	
	public List getColumnHeaders() {
		return this.columnHeaders;
	}
	
	public List<List<String>> getTeamStats(){
		return this.teamStats;
	}
	
	public void displayTeamStats() {
		for (List<String> team : teamStats) {
			System.out.println(team);
		}
	}
}

