package parser;
public interface StandingsParser extends Runnable {
	
}
