package parser;

import org.jsoup.nodes.Document;

public interface StandingsParser extends Runnable {

}
