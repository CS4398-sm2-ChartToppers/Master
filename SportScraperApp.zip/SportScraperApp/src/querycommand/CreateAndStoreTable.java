package querycommand;

public class CreateAndStoreTable implements QueryCommand {

	@Override
	public void run() {
		//call StoreDB's createTable method
		//call StoreDB's setRowData method in for loop to populate table
		
	}


}
