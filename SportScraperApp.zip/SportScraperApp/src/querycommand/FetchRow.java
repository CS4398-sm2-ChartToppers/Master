package querycommand;

public class FetchRow implements QueryCommand {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

	

}
