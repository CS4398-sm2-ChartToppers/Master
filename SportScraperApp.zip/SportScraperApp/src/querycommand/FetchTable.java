package querycommand;

public class FetchTable implements QueryCommand {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}


}
