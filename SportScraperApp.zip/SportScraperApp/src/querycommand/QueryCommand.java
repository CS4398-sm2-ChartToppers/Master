package querycommand;

public interface QueryCommand extends Runnable{
	@Override
	public void run();
}
