package Model;

/**
 * Interface for RetrieveRS class.
 */
public interface Model { void execute(String sport); }