package parser;

/**
 * Interface for different categories of parsers that allows running.
 */
public interface StandingsParser extends Runnable { }